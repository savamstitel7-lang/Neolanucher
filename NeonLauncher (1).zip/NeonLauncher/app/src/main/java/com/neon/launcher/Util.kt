package com.neon.launcher

import android.content.Context
import android.util.TypedValue
import android.widget.TextView

object Neon {
    val BG = 0xFF05010F.toInt()
    val CYAN = 0xFF00F0FF.toInt()
    val MAGENTA = 0xFFFF2BD6.toInt()
    val PURPLE = 0xFF7A2CFF.toInt()
    val DIM = 0xFF5A4A8A.toInt()
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

/** Размер текста в dp: не зависит от настройки "размер шрифта" в системе. */
fun TextView.sizeDp(v: Float) = setTextSize(TypedValue.COMPLEX_UNIT_DIP, v)
