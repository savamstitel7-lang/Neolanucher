package com.neon.launcher

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.view.View
import java.util.Random

/** Анимированный фон: тёмная неоновая сетка и "дождь" из символов. */
class NeonBackground(context: Context) : View(context) {

    private val glyphs = "01<>/\\{}[]#\$%&*+=:;".toCharArray()
    private val rnd = Random()
    private val cell = context.dp(15).toFloat()
    private val trail = 12

    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.MONOSPACE
        textSize = cell * 0.95f
        textAlign = Paint.Align.CENTER
    }
    private val gridPaint = Paint().apply {
        color = Neon.PURPLE
        alpha = 30
        strokeWidth = 1f
    }

    private var ys = FloatArray(0)
    private var speeds = FloatArray(0)

    private val frame = object : Runnable {
        override fun run() {
            step()
            invalidate()
            postDelayed(this, 40)
        }
    }

    private fun newSpeed() = cell * (0.12f + rnd.nextFloat() * 0.3f)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        val cols = (w / cell).toInt() + 1
        ys = FloatArray(cols) { rnd.nextFloat() * h }
        speeds = FloatArray(cols) { newSpeed() }
    }

    private fun step() {
        for (i in ys.indices) {
            ys[i] += speeds[i]
            if (ys[i] - trail * cell > height) {
                ys[i] = -rnd.nextFloat() * height * 0.4f
                speeds[i] = newSpeed()
            }
        }
    }

    override fun onDraw(c: Canvas) {
        c.drawColor(Neon.BG)

        val gridStep = cell * 4
        var x = 0f
        while (x < width) {
            c.drawLine(x, 0f, x, height.toFloat(), gridPaint)
            x += gridStep
        }
        var y = 0f
        while (y < height) {
            c.drawLine(0f, y, width.toFloat(), y, gridPaint)
            y += gridStep
        }

        for (i in ys.indices) {
            val cx = i * cell + cell / 2
            val magenta = i % 6 == 0
            for (t in 0 until trail) {
                val gy = ys[i] - t * cell
                if (gy < 0 || gy > height + cell) continue
                textPaint.color = when {
                    t == 0 -> 0xFFD8FFFF.toInt()
                    magenta -> Neon.MAGENTA
                    else -> Neon.CYAN
                }
                textPaint.alpha = if (t == 0) 160 else (110 * (1f - t / trail.toFloat())).toInt()
                val idx = ((i * 31 + (gy / cell).toInt() * 17) and 0x7fffffff) % glyphs.size
                c.drawText(glyphs, idx, 1, cx, gy, textPaint)
            }
        }
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        removeCallbacks(frame)
        post(frame)
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(frame)
        super.onDetachedFromWindow()
    }

    override fun onWindowVisibilityChanged(visibility: Int) {
        super.onWindowVisibilityChanged(visibility)
        removeCallbacks(frame)
        if (visibility == VISIBLE) post(frame)
    }
}
