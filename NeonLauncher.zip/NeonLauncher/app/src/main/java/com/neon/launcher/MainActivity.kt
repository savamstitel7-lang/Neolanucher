package com.neon.launcher

import android.app.Activity
import android.app.AlertDialog
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.ColorDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class AppEntry(
    val label: String,
    val pkg: String,
    val intent: Intent,
    val icon: Drawable
)

class MainActivity : Activity() {

    private val mono: Typeface = Typeface.MONOSPACE
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var clock: TextView
    private lateinit var status: TextView
    private lateinit var search: EditText
    private lateinit var list: ListView
    private val adapter = AppAdapter()

    private var allApps: List<AppEntry> = emptyList()

    private val timeFmt = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
    private val dateFmt = SimpleDateFormat("EEE dd.MM.yyyy", Locale.getDefault())

    private val tick = object : Runnable {
        override fun run() {
            updateClock()
            handler.postDelayed(this, 500)
        }
    }

    private val pkgReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            loadApps()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Neon.BG
        window.navigationBarColor = Neon.BG
        setContentView(buildUi())
        loadApps()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter().apply {
            addAction(Intent.ACTION_PACKAGE_ADDED)
            addAction(Intent.ACTION_PACKAGE_REMOVED)
            addAction(Intent.ACTION_PACKAGE_CHANGED)
            addDataScheme("package")
        }
        registerReceiver(pkgReceiver, filter)
    }

    override fun onStop() {
        unregisterReceiver(pkgReceiver)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        handler.post(tick)
    }

    override fun onPause() {
        handler.removeCallbacks(tick)
        super.onPause()
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        // Нажатие "Домой": сбрасываем поиск и прокручиваем список вверх.
        search.setText("")
        hideKeyboard()
        list.setSelection(0)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        // Лаунчер не закрывается кнопкой "Назад", только очищает поиск.
        if (search.text.isNotEmpty()) search.setText("")
    }

    // ---------------------------------------------------------------- UI

    private fun buildUi(): View {
        val root = FrameLayout(this)
        root.addView(
            NeonBackground(this),
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )

        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(24), dp(20), dp(8))
        }

        val tag = TextView(this).apply {
            typeface = mono
            text = "[ NEON//LAUNCHER v1.0 ]"
            textSize = 12f
            letterSpacing = 0.15f
            setTextColor(Neon.MAGENTA)
            setShadowLayer(dp(6).toFloat(), 0f, 0f, Neon.MAGENTA)
        }
        column.addView(tag)

        clock = TextView(this).apply {
            typeface = mono
            textSize = 50f
            letterSpacing = 0.04f
            setTextColor(Neon.CYAN)
            setShadowLayer(dp(12).toFloat(), 0f, 0f, Neon.CYAN)
        }
        column.addView(clock)

        status = TextView(this).apply {
            typeface = mono
            textSize = 13f
            setTextColor(Neon.MAGENTA)
            setShadowLayer(dp(5).toFloat(), 0f, 0f, Neon.MAGENTA)
        }
        column.addView(status)

        val neonLine = View(this).apply {
            background = GradientDrawable(
                GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(Neon.MAGENTA, Neon.PURPLE, Neon.CYAN)
            )
        }
        column.addView(
            neonLine,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(2)).apply {
                topMargin = dp(14)
                bottomMargin = dp(14)
            }
        )

        search = EditText(this).apply {
            typeface = mono
            textSize = 16f
            hint = "> поиск приложения_"
            setHintTextColor(Neon.DIM)
            setTextColor(Neon.CYAN)
            setSingleLine(true)
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
            imeOptions = EditorInfo.IME_ACTION_GO
            setPadding(dp(14), dp(10), dp(14), dp(10))
            background = GradientDrawable().apply {
                setColor(Color.argb(150, 5, 1, 15))
                setStroke(dp(1), Neon.CYAN)
                cornerRadius = dp(6).toFloat()
            }
            addTextChangedListener(object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    applyFilter(s?.toString().orEmpty())
                }
            })
            setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_GO) {
                    adapter.items.firstOrNull()?.let { launch(it) }
                    true
                } else {
                    false
                }
            }
        }
        column.addView(
            search,
            LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        )

        list = ListView(this).apply {
            divider = null
            dividerHeight = 0
            cacheColorHint = Color.TRANSPARENT
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
            adapter = this@MainActivity.adapter
            setOnItemClickListener { _, _, position, _ ->
                this@MainActivity.adapter.items.getOrNull(position)?.let { launch(it) }
            }
            setOnItemLongClickListener { _, _, position, _ ->
                this@MainActivity.adapter.items.getOrNull(position)?.let { showActions(it) }
                true
            }
        }
        column.addView(
            list,
            LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f)
        )

        root.addView(
            column,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        return root
    }

    private fun updateClock() {
        val now = Date()
        val cursor = if ((now.time / 500) % 2 == 0L) "_" else " "
        clock.text = timeFmt.format(now)
        status.text = "root@honor20lite:~$ ${dateFmt.format(now)} | BAT ${batteryPercent()}%$cursor"
    }

    private fun batteryPercent(): Int {
        val i = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED)) ?: return 0
        val level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1)
        val scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, -1)
        return if (level >= 0 && scale > 0) level * 100 / scale else 0
    }

    // ---------------------------------------------------------------- Apps

    private fun loadApps() {
        Thread {
            val pm = packageManager
            val query = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val apps = pm.queryIntentActivities(query, 0)
                .filter { it.activityInfo.packageName != packageName }
                .map { ri ->
                    val pkg = ri.activityInfo.packageName
                    AppEntry(
                        label = ri.loadLabel(pm).toString(),
                        pkg = pkg,
                        intent = Intent(Intent.ACTION_MAIN)
                            .addCategory(Intent.CATEGORY_LAUNCHER)
                            .setClassName(pkg, ri.activityInfo.name)
                            .addFlags(
                                Intent.FLAG_ACTIVITY_NEW_TASK or
                                    Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED
                            ),
                        icon = ri.loadIcon(pm)
                    )
                }
                .sortedBy { it.label.lowercase(Locale.getDefault()) }
            runOnUiThread {
                allApps = apps
                applyFilter(search.text.toString())
            }
        }.start()
    }

    private fun applyFilter(query: String) {
        val q = query.trim().lowercase(Locale.getDefault())
        adapter.items = if (q.isEmpty()) {
            allApps
        } else {
            allApps.filter {
                it.label.lowercase(Locale.getDefault()).contains(q) || it.pkg.contains(q)
            }
        }
        adapter.notifyDataSetChanged()
    }

    private fun launch(app: AppEntry) {
        try {
            startActivity(app.intent)
            search.setText("")
            hideKeyboard()
        } catch (e: Exception) {
            Toast.makeText(this, "ERR: не удалось запустить", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showActions(app: AppEntry) {
        val actions = arrayOf("// инфо о приложении", "// удалить")
        AlertDialog.Builder(this, android.R.style.Theme_Material_Dialog_Alert)
            .setTitle("> ${app.label.lowercase(Locale.getDefault())}")
            .setItems(actions) { _, which ->
                val uri = Uri.parse("package:${app.pkg}")
                try {
                    when (which) {
                        0 -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, uri))
                        1 -> startActivity(Intent(Intent.ACTION_DELETE, uri))
                    }
                } catch (e: Exception) {
                    Toast.makeText(this, "ERR: действие недоступно", Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(search.windowToken, 0)
        search.clearFocus()
    }

    // ---------------------------------------------------------------- List

    inner class AppAdapter : BaseAdapter() {
        var items: List<AppEntry> = emptyList()

        override fun getCount() = items.size
        override fun getItem(position: Int) = items[position]
        override fun getItemId(position: Int) = position.toLong()

        override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
            val row = (convertView as? AppRow) ?: AppRow(this@MainActivity)
            row.bind(items[position], position)
            return row
        }
    }

    inner class AppRow(context: Context) : LinearLayout(context) {
        private val index = TextView(context)
        private val icon = ImageView(context)
        private val name = TextView(context)

        init {
            orientation = HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(6), dp(7), dp(6), dp(7))
            background = StateListDrawable().apply {
                addState(
                    intArrayOf(android.R.attr.state_pressed),
                    ColorDrawable(Color.argb(60, 0, 240, 255))
                )
                addState(intArrayOf(), ColorDrawable(Color.TRANSPARENT))
            }

            index.apply {
                typeface = mono
                textSize = 11f
                setTextColor(Neon.MAGENTA)
            }
            addView(index, LayoutParams(dp(30), LayoutParams.WRAP_CONTENT))

            addView(icon, LayoutParams(dp(36), dp(36)).apply { rightMargin = dp(14) })

            name.apply {
                typeface = mono
                textSize = 18f
                setSingleLine(true)
                setTextColor(Neon.CYAN)
                setShadowLayer(dp(4).toFloat(), 0f, 0f, Neon.CYAN)
            }
            addView(name, LayoutParams(0, LayoutParams.WRAP_CONTENT, 1f))
        }

        fun bind(app: AppEntry, position: Int) {
            index.text = String.format(Locale.US, "%02d", position + 1)
            icon.setImageDrawable(app.icon)
            name.text = "./" + app.label.lowercase(Locale.getDefault())
        }
    }
}
